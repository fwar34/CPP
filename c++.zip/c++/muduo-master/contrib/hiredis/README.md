# Hiredis

The version of hiredis must be 0.11.0 or greater

See also issue [#92](https://github.com/chenshuo/muduo/issues/92)
