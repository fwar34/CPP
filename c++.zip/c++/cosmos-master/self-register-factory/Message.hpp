#pragma once
#include <iostream>

class Message
{
public:
	virtual ~Message() {}

	virtual void foo()
	{

	}
};
